package minesweeper;

import org.checkerframework.checker.units.qual.A;
import processing.core.PApplet;
import processing.core.PImage;
import processing.data.JSONArray;
import processing.data.JSONObject;
import processing.event.KeyEvent;
import processing.event.MouseEvent;

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import java.io.*;
import java.util.*;

public class App extends PApplet {

    public static final int CELLSIZE = 32; //8;
    public static final int CELLHEIGHT = 32;

    public static final int CELLAVG = 32;
    public static final int TOPBAR = 64;
    public static int WIDTH = 864; //CELLSIZE*BOARD_WIDTH;
    public static int HEIGHT = 640; //BOARD_HEIGHT*CELLSIZE+TOPBAR;
    public static final int BOARD_WIDTH = WIDTH/CELLSIZE;
    public static final int BOARD_HEIGHT = 20;

    public static final int FPS = 30;
    public static final int numberImage = 10;

    public String configPath;

    public static Random random = new Random();

    

    public static final int GAMEBOARDHEIGHT = (HEIGHT - TOPBAR)/CELLSIZE; //28
    public static final int GAMEBOARDWIDTH = BOARD_WIDTH; //27

    public static int numberMines = 100;

    

    private PImage[][] board = new PImage[GAMEBOARDHEIGHT][GAMEBOARDWIDTH];
    private boolean[][] mines;
    private boolean[][] flags;
    private boolean[][] revealedTile;
    private PImage[] explosionImages = new PImage[10];
    private int[][] setText;

    private boolean gameOver;
    private int seconds;
    private int frameCount;
    private boolean restart;
    private int currentImageIndex;

	
	public static int[][] mineCountColour = new int[][] {
            {0,0,0}, // 0 is not shown
            {0,0,255},
            {0,133,0},
            {255,0,0},
            {0,0,132},
            {132,0,0},
            {0,132,132},
            {132,0,132},
            {32,32,32}
    };
	
	// Feel free to add any additional methods or attributes you want. Please put classes in different files.

    public App() {
        this.configPath = "config.json";
    }

    /**
     * Initialise the setting of the window size.
     */
	@Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    private void initTile() {

        for(int i = 0; i < GAMEBOARDHEIGHT; i ++){
            for(int j = 0; j < GAMEBOARDWIDTH; j++){
                board[i][j] = loadImage("minesweeper/tile1.png");
            }
            
        }
    }
 
    private void initMines() {

        if (numberMines < 0) {
            numberMines = 100;
        }
    
        
        for (int i = 0; i < GAMEBOARDHEIGHT; i++) {
            Arrays.fill(mines[i], false);
        }
    
        for (int i = 0; i < numberMines; i++) {
            int col;
            int row;
            do {
                col = random.nextInt(GAMEBOARDWIDTH);
                row = random.nextInt(GAMEBOARDHEIGHT);
            } while (mines[row][col]); 
            mines[row][col] = true;
        }

        
    }


    /**
     * Load all resources such as images. Initialise the elements such as the player and map elements.
     */
	@Override
    public void setup() {
        frameRate(FPS);
		//See PApplet javadoc:
		//loadJSONObject(configPath)
		//loadImage(this.getClass().getResource(filename).getPath().toLowerCase(Locale.ROOT).replace("%20", " "));

        //create attributes for data storage, eg board

        mines = new boolean[GAMEBOARDHEIGHT][GAMEBOARDWIDTH];
        flags = new boolean[GAMEBOARDHEIGHT][GAMEBOARDWIDTH];
        revealedTile = new boolean[GAMEBOARDHEIGHT][GAMEBOARDWIDTH];
        setText = new int[GAMEBOARDHEIGHT][GAMEBOARDWIDTH];

        for(int i = 0; i < numberImage; i++){
            explosionImages[i] = loadImage("minesweeper/mine" + i + ".png");

        }

        gameOver = false;
        seconds = 0;
        frameCount = 0;
        restart = false;
        currentImageIndex = 0;

        initTile();
        initMines();

        // Debug information for mines
        System.out.println("Initial mines setup:");
        for (int i = 0; i < GAMEBOARDHEIGHT; i++) {
            for (int j = 0; j < GAMEBOARDWIDTH; j++) {
                System.out.print(mines[i][j] ? "M " : ". ");
            }
            System.out.println(); 
        }

    }

    /**
     * Receive key pressed signal from the keyboard.
     */
	@Override
    public void keyPressed(KeyEvent event){

        if(key == 'r'){
            restart = true;
        }
        
    }

    /**
     * Receive key released signal from the keyboard.
     */
	@Override
    public void keyReleased(){
        
    }

    public int countMines(int row, int col) {
        int count = 0;

        for(int i = -1; i <= 1; i++){
            for(int j = -1; j <= 1; j++){
                int newRow = row + i;
                int newCol = col + j;

                if(newRow >= 0 && newCol >=0 && newRow < GAMEBOARDHEIGHT && newCol < GAMEBOARDWIDTH && mines[newRow][newCol] == true){
                    count += 1;

                }

            }
        }

        return count;
       
    }

    public boolean canReveal(int row, int col) {
        if(mines[row][col] == false && flags[row][col] == false && revealedTile[row][col] == false){
            return true;
        }
        return false;
    }

    public void revealEmptyTile(int row, int col) {
        if (revealedTile[row][col]) return; 
    
        int count = countMines(row, col);
        revealedTile[row][col] = true; 
        setText[row][col] = count; 
    
       
        if (count == 0) {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    int newRow = row + i;
                    int newCol = col + j;
    
                    if (newRow >= 0 && newCol >= 0 && newRow < GAMEBOARDHEIGHT && newCol < GAMEBOARDWIDTH) {
                        revealEmptyTile(newRow, newCol); 
                    }
                }
            }
        }
    }
    

    @Override
    public void mousePressed(MouseEvent e) {

        if (!gameOver) {
           
            int col = e.getX() / CELLSIZE;
            int row = (e.getY() - TOPBAR) / CELLSIZE; 
    
           
            if (row >= 0 && row < GAMEBOARDHEIGHT && col >= 0 && col < GAMEBOARDWIDTH) {
    
                if (mouseButton == LEFT) {
                    
                    if (!flags[row][col]) {
                        
                        if (mines[row][col]) {
                            gameOver = true;
                        } else {
                            
                            revealEmptyTile(row, col);
                        }
                    }
    
                } else if (mouseButton == RIGHT) {
                    
                    flags[row][col] = !flags[row][col];
                }
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        

    }

    private void drawBoard() {
        int rowIndex = TOPBAR;
        for (int i = 0; i < GAMEBOARDHEIGHT; i++) {
            int colIndex = 0;
            for (int j = 0; j < GAMEBOARDWIDTH; j++) {
                
                if (revealedTile[i][j]) {
                    image(loadImage("minesweeper/tile.png"), colIndex, rowIndex);
                    
                    rect(colIndex, rowIndex, CELLSIZE, CELLSIZE);
                } else {
                    image(board[i][j], colIndex, rowIndex);
                }
    
                
                if (flags[i][j]) {
                    image(loadImage("minesweeper/flag.png"), colIndex, rowIndex);  // flagImage 应该在 setup 中预加载
                }
    
                
                if (revealedTile[i][j] && setText[i][j] > 0) {
                    int count = setText[i][j];
                    int r = mineCountColour[count][0];
                    int g = mineCountColour[count][1];
                    int b = mineCountColour[count][2];
    
                    fill(r, g, b);
                    textSize(20);
                    textAlign(CENTER, CENTER);
                    text(count, colIndex + CELLSIZE / 2, rowIndex + CELLSIZE / 2);
                }
    
                colIndex += CELLSIZE;
            }
            rowIndex += CELLSIZE;
        }
    }
    

    public boolean winGame() {

        for (int i = 0; i < GAMEBOARDHEIGHT; i++) {
            for (int j = 0; j < GAMEBOARDWIDTH; j++) {
                if (mines[i][j] && !flags[i][j]) {
                    return false; 
                }
                if (!mines[i][j] && !revealedTile[i][j]) {
                    return false; 
                }
            }
        }
        return true; 

    }

    public void hoveringOver(){
        int col = (int) mouseX / 32;
        int row = (int) (mouseY - TOPBAR) / 32;

        if(row >= 0 && row < GAMEBOARDHEIGHT && col < GAMEBOARDWIDTH && revealedTile[row][col] == false){
            image(loadImage("minesweeper/tile2.png"), col * 32, row * 32);
        
        }

    }

    public void mineExploration() {
        boolean explosion = false;

        int rowIndex = TOPBAR;
        for(int i = 0; i < GAMEBOARDHEIGHT; i++){
            int colIndex = 0;
            for(int j = 0; j < GAMEBOARDWIDTH; j ++){
                if(mines[i][j]){
                    image(explosionImages[currentImageIndex], colIndex, rowIndex);
                    explosion = true;
                }
                colIndex += 32;
            }
            rowIndex += 32;
        }
        if(explosion){
            if(frameCount % 3 == 0){
                currentImageIndex += 1;
                if(currentImageIndex >= 10){
                    currentImageIndex = 9;
                }
            }
        }

    }

    /**
     * Draw all elements in the game by current frame.
     */
	@Override
    public void draw() {
        
        if (winGame()) {
            drawBoard();
            fill(0);
            textSize(24);
            text("You Win!", 10, 57);
        
        } else {
            
            if (!gameOver) {
                if (frameCount % 30 == 0) {
                    background(255);
                    fill(0);
                    textSize(23);
                    text("Time: " + seconds, 650, 57);
                    seconds += 1;
                }
    
                drawBoard();
                hoveringOver();
    
            } else {
                drawBoard();
                fill(0);
                textSize(24);
                text("You Lose!", 10, 57);
    
                mineExploration();
            }
        }

        frameCount += 1;
    
       
        if (restart) {
            setup(); 
            restart = false;  
        }
    }


    public static void main(String[] args) {
        int numberMines = 100; 

        if (args.length > 0) {
            try {
                numberMines = Integer.parseInt(args[0]);
                if (numberMines <= 0) {
                    numberMines = 100; 
                }
            } catch (NumberFormatException e) {
                
                numberMines = 100;
            }
        }
        App.numberMines = numberMines;
        PApplet.main("minesweeper.App");
    }

}
